<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Press_release extends Model
{
    //
}
